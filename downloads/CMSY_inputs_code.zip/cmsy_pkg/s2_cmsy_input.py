import pandas as pd, numpy as np
W = '/home/claude/work/'
d = pd.read_pickle(W + 'stage1.pkl')
C, tax, ssp, YRS = d['C'], d['tax'], d['ssp'], d['YRS']
unit = pd.read_excel(W + 'prior.xlsx', sheet_name='資源單位先驗')
unit = unit[unit['階段'].str[:1].isin(['一', '二'])].drop_duplicates('資源單位').set_index('資源單位')
sp = pd.read_excel(W + 'prior.xlsx', sheet_name='物種先驗').drop_duplicates('學名').set_index('學名')

unit_map = {'Common squids NEI': 'TW36_Common_squids', 'Groupers NEI': 'TW46_Groupers', 'Filefishes NEI': 'TW47_Filefishes',
            'Goatfishes': 'TW49_Goatfishes', 'Snappers, jobfishes NEI': 'TW50_Snappers', 'Deep water tilefishes NEI': 'TW51_Tilefishes',
            'Flyingfishes NEI': 'TW53_Flyingfishes', 'Barracudas NEI': 'TW54_Barracudas', 'Sea catfishes NEI': 'TW56_Sea_catfishes',
            'Sillago-whitings': 'TW58_Sillago_whitings', 'Porgies, seabreams NEI': 'TW43_Porgies_seabreams',
            'Croakers, drums NEI': 'TW07_Croakers', 'Butterfishes, pomfrets NEI': 'TW13_Pomfrets',
            'Frigate and bullet tunas': 'TW22_Frigate_and_bullet_tunas', 'Seerfishes NEI': 'TW23_Seerfishes',
            'Jacks, crevalles NEI': 'TW03_Jacks_and_scads', 'Scads NEI': 'TW79_Scads', 'Indian scad': 'TW79_Scads',
            'Torpedo scad': 'TW03_Jacks_and_scads', 'Metapenaeus shrimps NEI': 'TW73_Metapenaeus_shrimps',
            'Octopuses, etc. NEI': 'TW62_Octopuses', 'Largehead hairtail': 'TW01_Largehead_hairtail',
            'Silver seabream': 'TW67_Silver_seabream', 'Chinese gizzard shad': 'TW19_Herrings_sardines_anchovies',
            'Fourfinger threadfin': 'TW14_Fourfinger_threadfin', 'Oilfish': 'TW52_Oilfish'}
default_res = {'Pacific saury': 'High', 'Abalones NEI': 'Low', 'Pearl oyster shells NEI': 'Medium', 'Blood cockle': 'Medium',
               'Japanese carpet shell': 'Medium', 'Japanese hard clam': 'Medium', 'Pacific cupped oyster': 'Medium',
               'Yesso scallop': 'Medium', 'Alaska pollock (=walleye pollock)': 'Medium', 'Barramundi(=Giant seaperch)': 'Medium',
               'Japanese seabass': 'Medium', 'Ocean sunfish': 'Low', 'Bluefin gurnard': 'Medium'}
RES = {'High': (0.6, 1.5), 'Medium': (0.2, 0.8), 'Low': (0.05, 0.5), 'Very low': (0.015, 0.1)}

def prior_for(r):
    en = r.en
    if en in unit_map:
        u = unit.loc[unit_map[en]]
        return u.建議r_低, u.建議r_高, f'資源單位先驗 {unit_map[en]}（{u.取值層級[:14]}）'
    s1 = r.sci.split(',')[0].strip()
    # Taiwan unit priors with identical scientific name (include local literature level L)
    m = unit[unit.學名.str.strip() == s1]
    if len(m):
        u = m.iloc[0]
        return u.建議r_低, u.建議r_高, f'資源單位先驗 {m.index[0]}（{u.取值層級[:14]}）'
    for nm in [s1, r.asfis_sci]:
        if nm in sp.index:
            u = sp.loc[nm]
            return u.建議r_低, u.建議r_高, f'物種先驗 {nm}（{u.取值層級[:14]}）'
    if r.gen not in ('', '—'):
        g = sp[sp.index.str.split().str[0] == r.gen]
        if len(g):
            return np.exp(np.log(g.建議r_低).mean()), np.exp(np.log(g.建議r_高).mean()), f'同屬 {len(g)} 種物種先驗幾何平均'
    if r.fam == 'Scaridae':
        g = sp[sp.index.str.startswith('Scarus ')]
        return np.exp(np.log(g.建議r_低).mean()), np.exp(np.log(g.建議r_高).mean()), f'鸚哥魚科 Scarus {len(g)} 種物種先驗幾何平均'
    if r.fam == 'Istiophoridae':
        g = sp.loc[['Istiompax indica', 'Istiophorus platypterus', 'Kajikia audax', 'Makaira nigricans']]
        return np.exp(np.log(g.建議r_低).mean()), np.exp(np.log(g.建議r_高).mean()), '旗魚科 4 種物種先驗幾何平均'
    if en in default_res:
        lo, hi = RES[default_res[en]]
        return lo, hi, f'Resilience 預設範圍（{default_res[en]}）'
    return np.nan, np.nan, '無'

pr = tax.apply(prior_for, axis=1, result_type='expand')
tax['r_low'], tax['r_hi'], tax['r_src'] = pr[0], pr[1], pr[2]

ids, cts, sel = [], [], []
for _, s in ssp[ssp.included].iterrows():
    en = s.en; r = tax[tax.en == en].iloc[0]
    x = C.loc[en].values
    nz = np.where(x > 0)[0]
    first, last = nz[0], nz[-1]
    # start after the last zero gap of >=3 years
    z = (x[first:last + 1] == 0).astype(int)
    st = first
    run = 0
    for i, b in enumerate(z):
        run = run + 1 if b else 0
        if run >= 3: st = first + i + 1
    nyr = last - st + 1
    zf = (x[st:last + 1] == 0).mean()
    ok = nyr >= 15 and zf <= 0.15 and not np.isnan(r.r_low)
    why = '' if ok else ('年數<15' if nyr < 15 else '零漁獲比例>15%' if zf > 0.15 else '無 r 先驗')
    sel.append(dict(en=en, cmsy_start=int(YRS[st]), cmsy_end=int(YRS[last]), cmsy_nyr=int(nyr), zero_frac=zf, cmsy_run=ok, cmsy_skip=why))
    if not ok: continue
    stock = 'TW_' + r.code
    ct3 = x[st:st + 3].mean(); mx = x[st:last + 1].max()
    stb = (0.75, 1.0) if (YRS[st] <= 1960 and ct3 < 0.33 * mx) else (np.nan, np.nan)
    ids.append(dict(Continent='Asia', Region='Taiwan', Subregion='FAO Taiwan coastal catch', Stock=stock, Group=r.cls,
                    Name=f'{r.en} ({r.cn})', ScientificName=r.sci, SpecCode='', Source='FAO FishStat (Taiwan) 1950-2024',
                    MinOfYear=int(YRS[st]), MaxOfYear=int(YRS[last]), StartYear=int(YRS[st]), EndYear=int(YRS[last]),
                    Flim=np.nan, Fpa=np.nan, Blim=np.nan, Bpa=np.nan, Bmsy=np.nan, MSYBtrigger=np.nan, Fmsy=np.nan, last_F=np.nan,
                    Resilience=min(RES, key=lambda k: abs(np.log(np.sqrt(r.r_low*r.r_hi))-np.log(np.sqrt(RES[k][0]*RES[k][1])))), **{'r.low': round(r.r_low, 4), 'r.hi': round(r.r_hi, 4), 'stb.low': stb[0], 'stb.hi': stb[1],
                    'int.yr': np.nan, 'intb.low': np.nan, 'intb.hi': np.nan, 'endb.low': np.nan, 'endb.hi': np.nan},
                    btype='None', **{'e.creep': np.nan, 'force.cmsy': 'FALSE'}, Comments=r.r_src))
    for i in range(st, last + 1):
        cts.append(dict(Stock=stock, yr=int(YRS[i]), ct=float(x[i]), bt=np.nan))
idf = pd.DataFrame(ids); cdf = pd.DataFrame(cts)
import os
os.makedirs(W + 'cmsy', exist_ok=True)
idf.to_csv(W + 'cmsy/TW_ID.csv', index=False, na_rep='NA')
cdf.to_csv(W + 'cmsy/TW_Catch.csv', index=False, na_rep='NA')
seldf = pd.DataFrame(sel)
d['tax'] = tax; d['cmsy_sel'] = seldf; d['cmsy_id'] = idf
pd.to_pickle(d, W + 'stage2.pkl')
print(len(idf), 'stocks for CMSY')
print(seldf[~seldf.cmsy_run].to_string())
print(idf[['Stock', 'Name', 'StartYear', 'EndYear', 'r.low', 'r.hi', 'stb.low', 'Comments']].to_string())
print(tax[tax.r_src == '無'][['en', 'level']].to_string())
