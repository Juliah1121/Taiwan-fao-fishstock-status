#!/bin/bash
s=$1; d=/home/claude/work/cmsy/run/$s; mkdir -p $d; cd $d; rm -f *
Rscript /home/claude/work/cmsy/CMSYpp16_TW.R $s > log.txt 2>&1
echo "$s done $(ls *.jpg 2>/dev/null | wc -l)"
