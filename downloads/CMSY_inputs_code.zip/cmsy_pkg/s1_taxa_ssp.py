import pandas as pd, numpy as np, re, json
W = '/home/claude/work/'
catch = pd.read_excel(W + 'catch.xlsx')
catch = catch.rename(columns={catch.columns[0]: 'en'})
catch['en'] = catch['en'].str.strip()
years = [c for c in catch.columns if c != 'en']
YRS = np.array(years, dtype=int)

# ---------- 1. taxonomy ----------
a = pd.read_csv('/home/claude/ext/asfis.csv', encoding='latin1')
a['k'] = a.English_name.fillna('').str.lower().str.replace(r'[^a-z]', '', regex=True)
alias = {'Alaska pollock (=walleye pollock)': 'ALK', 'Pacific chub mackerel': 'MAS', 'Sailfish': 'SFA',
         'Deep water tilefishes NEI': 'TIS', 'Marine bivalves NEI': 'CLX'}
man = pd.read_csv(W + 'taxa_manual.tsv', sep='\t').fillna('')
# order convention: follow the user's vulnerability database (broad Perciformes; Scombriformes/Carangiformes/Istiophoriformes split)
ord_fix = {'Sciaenidae': 'Perciformes', 'Priacanthidae': 'Perciformes', 'Mullidae': 'Perciformes', 'Lutjanidae': 'Perciformes',
           'Lethrinidae': 'Perciformes', 'Nemipteridae': 'Perciformes', 'Sparidae': 'Perciformes', 'Malacanthidae': 'Perciformes',
           'Sillaginidae': 'Perciformes', 'Sphyraenidae': 'Perciformes', 'Polynemidae': 'Perciformes', 'Latidae': 'Perciformes',
           'Triglidae': 'Scorpaeniformes', 'Scaridae': 'Perciformes', 'Epinephelidae': 'Perciformes'}
fam_fix = {'Epinephelidae': 'Serranidae'}
cls_cn = {'Actinopterygii': '條鰭魚綱', 'Elasmobranchii': '板鰓亞綱（軟骨魚綱）', 'Gastropoda': '腹足綱', 'Bivalvia': '雙殼綱',
          'Cephalopoda': '頭足綱', 'Malacostraca': '軟甲綱', 'Anthozoa': '珊瑚綱', 'Demospongiae': '尋常海綿綱',
          'Echinoidea': '海膽綱', 'Holothuroidea': '海參綱', 'Florideophyceae': '真紅藻綱', 'Bangiophyceae': '紅毛菜綱',
          'Ulvophyceae': '石蓴綱', '—': '—'}
rows = []
for _, m in man.iterrows():
    en = m.en
    if en in alias:
        hit = a[a.X3A_CODE == alias[en]]
    else:
        hit = a[a.k == re.sub(r'[^a-z]', '', en.lower())]
    h = hit.iloc[0]
    fam = fam_fix.get(m.fam, m.fam)
    order = ord_fix.get(m.fam, m.ord)
    rows.append(dict(en=en, cn=m.cn, asfis_sci=h.Scientific_name, sci=m.valid, code=h.X3A_CODE,
                     isscaap=int(h.ISSCAAP) if pd.notna(h.ISSCAAP) else None, taxocode=h.TAXOCODE,
                     cls=m.cls, cls_cn=cls_cn.get(m.cls, m.cls), ord=order, fam=fam, gen=m.gen, level=m.level,
                     note=m.note, asfis_family=h.Family if pd.notna(h.Family) else '', asfis_order=h.Order))
tax = pd.DataFrame(rows)
assert len(tax) == len(catch) and set(tax.en) == set(catch.en), set(catch.en) ^ set(tax.en)

# ---------- vulnerability link ----------
v = pd.read_excel(W + 'vul.xlsx', header=3)
v.columns = ['no', 'cn', 'en', 'sci', 'cls', 'ord', 'fam', 'tmax', 'tm', 'ref', 'k', 'rep', 'dbl', 'dist', 'vs', 'vc', 'fao']
v['sci'] = v.sci.str.strip()
v['fam_lat'] = v.fam.str.extract(r'\(([^)]+)\)')
v['gen'] = v.sci.str.split().str[0]
def vul_for(r):
    sp = r.sci.split(',')[0].strip()
    if r.level == '種':
        q = v[v.sci.str.lower() == sp.lower()]
        if len(q) == 0:
            alt = {'Gadus chalcogrammus': 'Theragra chalcogramma', 'Kajikia audax': 'Tetrapturus audax',
                   'Istiompax indica': 'Makaira indica', 'Etrumeus micropus': 'Etrumeus teres', 'Pagrus auratus': 'Pagrus major'}
            q = v[v.sci.str.lower() == alt.get(sp, '#').lower()]
        if len(q):
            return q.vs.iloc[0], q.vc.iloc[0], '物種相符（' + q.sci.iloc[0] + '）', 1
    q = v[v.fao == r.code]
    if len(q):
        return q.vs.mean(), None, f'FAO代碼 {r.code} 相符之 {len(q)} 種平均', len(q)
    if r.gen not in ('', '—'):
        q = v[v.gen == r.gen]
        if len(q):
            return q.vs.mean(), None, f'同屬 {len(q)} 種平均', len(q)
    if r.fam not in ('', '—'):
        q = v[v.fam_lat == r.fam]
        if len(q):
            return q.vs.mean(), None, f'同科 {len(q)} 種平均', len(q)
    return None, None, '無對應', 0
def vcat(s):
    if s is None or pd.isna(s): return ''
    return 'Very high (極高)' if s >= 75 else 'High (高)' if s >= 55 else 'Moderate (中等)' if s >= 35 else 'Low (低)'
vv = tax.apply(vul_for, axis=1, result_type='expand')
tax['vul_score'] = vv[0].astype(float).round(1)
tax['vul_cat'] = [c if c else vcat(s) for c, s in zip(vv[1], tax.vul_score)]
tax['vul_src'] = vv[2]

# ---------- 2. SSP ----------
C = catch.set_index('en')[years].astype(float).fillna(0)
C.columns = YRS
NONFISH = {'Anthozoa', 'Demospongiae', 'Florideophyceae', 'Bangiophyceae', 'Ulvophyceae'}
tax = tax.set_index('en').loc[C.index].reset_index()

def smooth(x):
    return pd.Series(x).rolling(3, center=True, min_periods=1).mean().values

def max_run(nz):
    best = cur = 0
    for b in nz:
        cur = cur + 1 if b else 0
        best = max(best, cur)
    return best

def classify(sm, first, last):
    """status per year (index into YRS) for smoothed series sm; years before first reported are None."""
    st = [None] * len(sm)
    idx = np.arange(first, last + 1)
    seg = sm[first:last + 1]
    p = first + int(np.argmax(seg)); cmax = sm[p]
    post = np.arange(p + 1, last + 1)
    pmin = post[np.argmin(sm[post])] if len(post) else None
    for t in idx:
        f = sm[t] / cmax if cmax > 0 else 0
        if p == len(sm) - 1:          # peak in final year of the series -> Developing (SAU rule)
            st[t] = 'Developing'
        elif t <= p:
            st[t] = 'Developing' if (f <= 0.5 and t < p) else 'Exploited'
        else:
            if f >= 0.5: st[t] = 'Exploited'
            elif f < 0.1: st[t] = 'Collapsed'
            elif pmin is not None and t > pmin: st[t] = 'Rebuilding'
            else: st[t] = 'Over-exploited'
    return st, p, cmax, pmin

ssp_rows, status_yr, smoothed = [], {}, {}
for en, row in C.iterrows():
    x = row.values
    r = tax[tax.en == en].iloc[0]
    nz = x > 0
    sm = smooth(x)
    smoothed[en] = sm
    info = dict(en=en)
    if nz.any():
        first, last = int(np.argmax(nz)), int(len(x) - 1 - np.argmax(nz[::-1]))
    else:
        first = last = None
    reasons = []
    if r.level not in ('種', '屬', '科'): reasons.append('高階或混合類群')
    if r.cls in NONFISH: reasons.append('非 SAU 漁獲範圍（藻類／珊瑚／海綿）')
    if first is None: reasons.append('無漁獲')
    else:
        if YRS[last] - YRS[first] < 10: reasons.append('首末年相距<10年')
        if max_run(nz[first:last + 1]) < 5: reasons.append('連續漁獲<5年')
        if x.sum() < 100: reasons.append('累計漁獲<100 t')
    inc = len(reasons) == 0
    info.update(first=int(YRS[first]) if first is not None else None, last=int(YRS[last]) if last is not None else None,
                total=x.sum(), maxrun=max_run(nz), included=inc, reason='；'.join(reasons))
    if first is not None:
        st, p, cmax, pmin = classify(sm, first, len(x) - 1)  # status runs to final data year (zeros after last = collapse)
        status_yr[en] = st
        info.update(peak_year=int(YRS[p]), peak_sm=cmax, raw_peak=x.max(), raw_peak_year=int(YRS[np.argmax(x)]),
                    pmin_year=int(YRS[pmin]) if pmin is not None else None,
                    last_sm=sm[-1], last_pct=sm[-1] / cmax * 100 if cmax else None, status_last=st[-1])
    ssp_rows.append(info)
ssp = pd.DataFrame(ssp_rows)

cats = ['Developing', 'Exploited', 'Over-exploited', 'Collapsed', 'Rebuilding']
inc_names = ssp[ssp.included].en.tolist()
agg_n = pd.DataFrame(0, index=YRS, columns=cats, dtype=float)
agg_c = pd.DataFrame(0, index=YRS, columns=cats, dtype=float)
for en in inc_names:
    for i, s in enumerate(status_yr[en]):
        if s is None: continue
        agg_n.loc[YRS[i], s] += 1
        agg_c.loc[YRS[i], s] += smoothed[en][i]
pct_n = agg_n.div(agg_n.sum(axis=1).replace(0, np.nan), axis=0) * 100
pct_c = agg_c.div(agg_c.sum(axis=1).replace(0, np.nan), axis=0) * 100

stat_tbl = pd.DataFrame({en: status_yr.get(en, [None] * len(YRS)) for en in C.index}, index=YRS).T
sm_tbl = pd.DataFrame(smoothed, index=YRS).T

pd.to_pickle(dict(C=C, tax=tax, ssp=ssp, agg_n=agg_n, agg_c=agg_c, pct_n=pct_n, pct_c=pct_c, stat_tbl=stat_tbl,
                  sm_tbl=sm_tbl, YRS=YRS), W + 'stage1.pkl')
print(tax[['en', 'code', 'sci', 'cls', 'ord', 'fam', 'gen', 'level', 'vul_score', 'vul_src']].to_string())
print(ssp.included.sum(), 'stocks included')
print(ssp[ssp.included].status_last.value_counts())
print(pct_n.loc[[1960, 1980, 2000, 2024]].round(1))
print(pct_c.loc[[1960, 1980, 2000, 2024]].round(1))
print(ssp[~ssp.included][['en', 'reason']].to_string())
