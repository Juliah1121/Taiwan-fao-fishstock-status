fs <- list.files("/home/claude/work/cmsy/run", pattern="^cmsy_.*rdata$", recursive=TRUE, full.names=TRUE)
brp <- list(); ts <- list(); kb <- list()
for (f in fs) {
  load(f)
  s <- cmsy$stock; b <- cmsy$cmsy$brp
  brp[[s]] <- data.frame(stock=s, r=b[1,"r"], r_lcl=b[2,"r"], r_ucl=b[3,"r"], k=b[1,"k"], k_lcl=b[2,"k"], k_ucl=b[3,"k"],
     MSY=b[1,"MSY"], MSY_lcl=b[2,"MSY"], MSY_ucl=b[3,"MSY"], Bmsy=b[1,"Bmsy"], Fmsy=b[1,"Fmsy"])
  t <- cmsy$cmsy$timeseries
  ts[[s]] <- data.frame(stock=s, yr=as.numeric(dimnames(t)[[1]]), catch=cmsy$catch,
     BBmsy=t[,"mu","BBmsy"], BBmsy_lcl=t[,"lci","BBmsy"], BBmsy_ucl=t[,"uci","BBmsy"],
     FFmsy=t[,"mu","FFmsy"], FFmsy_lcl=t[,"lci","FFmsy"], FFmsy_ucl=t[,"uci","FFmsy"])
  k <- cmsy$cmsy$kobe
  kb[[s]] <- data.frame(stock=s, pRed=mean(k$BBmsy<1 & k$FFmsy>1), pYellow=mean(k$BBmsy<1 & k$FFmsy<=1),
     pOrange=mean(k$BBmsy>=1 & k$FFmsy>1), pGreen=mean(k$BBmsy>=1 & k$FFmsy<=1))
}
write.csv(merge(do.call(rbind,brp), do.call(rbind,kb)), "/home/claude/work/cmsy/brp.csv", row.names=FALSE)
write.csv(do.call(rbind,ts), "/home/claude/work/cmsy/ts.csv", row.names=FALSE)
cat(length(fs), "collected\n")
